A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/Cogca.

 Flat design accordion with as many nested levels as you need.  Click on it!

Forked from [Ryan Bobrowski](http://codepen.io/rbobrowski/)'s Pen [Multi-level Accordion](http://codepen.io/rbobrowski/pen/likvA/).